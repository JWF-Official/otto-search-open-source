# About Otto

Otto is made by Reality Inc LLC.

Being named after the founder's dog, Otto is free and safe for all.

If you enjoy Otto, you'll enjoy Mega OS.

Which can be found here: https://realityincllc.tk/MegaOS/
