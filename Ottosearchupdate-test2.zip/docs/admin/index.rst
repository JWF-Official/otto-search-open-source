===========================
Administrator documentation
===========================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation
   installation-Otto
   installation-uwsgi
   installation-nginx
   installation-apache
   installation-docker
   installation-switch2ng
   update-Otto
   engines/index
   api
   architecture
   filtron
   morty
   plugins
   buildhosts
