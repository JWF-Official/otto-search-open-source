.. _redis db:

========
Redis DB
========

.. automodule:: searx.shared.redisdb
  :members:
